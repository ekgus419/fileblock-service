import { useEffect, useState } from "react";
import {
  getFixedExtensions,
  updateFixedExtension,
  getCustomExtensions,
  addCustomExtension,
  removeCustomExtension,
} from "../api/extensionApi";

export default function ExtensionManager() {
  const [fixedExtensions, setFixedExtensions] = useState([]);
  const [customExtensions, setCustomExtensions] = useState([]);
  const [inputExt, setInputExt] = useState("");
  const [errorMessage, setErrorMessage] = useState("");

  // ✅ 초기 로딩
  useEffect(() => {
    getFixedExtensions().then((res) => {
      if (res.data.success) {
        setFixedExtensions(res.data.data || []);
      } else {
        setErrorMessage(res.data.error.message);
      }
    });
    getCustomExtensions().then((res) => {
      if (res.data.success) {
        setCustomExtensions(res.data.data || []);
      } else {
        setErrorMessage(res.data.error.message);
      }
    });
  }, []);

  // ✅ 고정 확장자 토글
  const toggleFixed = (ext) => {
    updateFixedExtension(ext.seq, !ext.isBlocked)
      .then((res) => {
        if (res.data.success) {
          const updated = res.data.data;
          setFixedExtensions((prev) =>
            prev.map((item) => (item.seq === ext.seq ? updated : item))
          );
        } else {
          setErrorMessage(res.data.error.message);
        }
      })
      .catch(() => setErrorMessage("고정 확장자 업데이트 실패"));
  };

  // ✅ 커스텀 확장자 추가
  const handleAdd = () => {
    if (!inputExt.trim()) return;
    addCustomExtension(inputExt.trim())
      .then((res) => {
        if (res.data.success) {
          setCustomExtensions((prev) => [...prev, res.data.data]);
          setInputExt("");
        } else {
          setErrorMessage(res.data.error.message);
        }
      })
      .catch(() => setErrorMessage("커스텀 확장자 추가 실패"));
  };

  // ✅ 커스텀 확장자 삭제
  const handleDelete = (seq) => {
    removeCustomExtension(seq)
      .then((res) => {
        if (res.data.success) {
          setCustomExtensions((prev) =>
            prev.filter((ext) => ext.seq !== seq)
          );
        } else {
          setErrorMessage(res.data.error.message);
        }
      })
      .catch(() => setErrorMessage("커스텀 확장자 삭제 실패"));
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-100">
      <div className="w-full max-w-2xl bg-white rounded-lg shadow p-8">
        <h2 className="text-lg font-bold mb-2 flex items-center gap-2">
          <span className="text-yellow-500">📂</span> 파일 확장자 차단
        </h2>
        <p className="text-sm text-gray-600 mb-6">
          파일확장자에 따라 특정 형식의 파일을 첨부하거나 전송하지 못하도록 제한
        </p>

        {/* 에러 메시지 출력 */}
        {errorMessage && (
          <div className="mb-4 p-3 rounded bg-red-100 text-red-700 text-sm">
            ❌ {errorMessage}
          </div>
        )}

        {/* ✅ 고정 확장자 */}
        <div className="mb-6">
          <h3 className="font-semibold mb-2">① 고정 확장자</h3>
          <div className="flex gap-3 flex-wrap">
            {fixedExtensions.map((ext) => (
              <label key={ext.seq} className="flex items-center gap-1">
                <input
                  type="checkbox"
                  checked={ext.isBlocked}
                  onChange={() => toggleFixed(ext)}
                  className="w-4 h-4"
                />
                {ext.extension}
              </label>
            ))}
          </div>
        </div>

        {/* ✅ 커스텀 확장자 */}
        <div>
          <h3 className="font-semibold mb-2">② 커스텀 확장자</h3>
          <div className="flex gap-2 mb-2">
            <input
              type="text"
              value={inputExt}
              onChange={(e) => setInputExt(e.target.value)}
              placeholder="확장자 입력"
              className="flex-1 border rounded px-3 py-2"
            />
            <button
              onClick={handleAdd}
              className="px-4 py-2 bg-gray-100 rounded hover:bg-gray-200"
            >
              +추가
            </button>
          </div>
          <div className="min-h-[120px] border rounded p-3 text-sm text-gray-600 flex flex-wrap gap-2">
            {customExtensions.map((ext) => (
              <span
                key={ext.seq}
                className="px-2 py-1 bg-gray-200 rounded flex items-center gap-1"
              >
                {ext.extension}
                <button
                  onClick={() => handleDelete(ext.seq)}
                  className="text-red-500 ml-1"
                >
                  ✕
                </button>
              </span>
            ))}
            <div className="w-full text-right text-xs text-gray-500">
              {customExtensions.length}/200
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
